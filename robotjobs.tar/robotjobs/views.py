# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.views import View
from lib.django.robot_execute import RobotExecute

class GetRobotService():

	def get_robot_service(self):
		return RobotExecute()

class JobScheduler(View):
	# template_name = 'product_index_old.html'
	template_name = 'job_scheduler.html'
	robot_data = GetRobotService().get_robot_service()

	def get(self, request, *args, **kwargs):
		suite_info, job_group_info = self.robot_data.get_suiteinfo()
		print(job_group_info)

		#get all job groups
		job_group_info_view = job_group_info.keys()
		#add the full and custom to the above
		job_group_info_view.extend(['full','custom'])
		job_run_list = None
		test_suite_list = None
		test_case_list = None
		
		context = {
		'job_groups': job_group_info_view,
		'job_run_list': job_run_list,
		'test_suite_list': test_suite_list,
		'test_case_list': test_case_list
		}

		return render(request, self.template_name, context)

	def post(self, request, *args, **kwargs):
		return render(request, self.template_name, context)		
		


class JobGroup(View):
	# template_name = 'product_index_old.html'
	template_name = 'job_scheduler.html'
	robot_data = GetRobotService().get_robot_service()
	
	def get(self, request, job_group_selected=None, *args, **kwargs):
		suite_info, job_group_info = self.robot_data.get_suiteinfo()
		print(job_group_info)

		#get all job groups
		job_group_info_view = job_group_info.keys()
		#add the full and custom to the above
		job_group_info_view.extend(['full','custom'])
		
		#get the list of suite names in the group
		job_run_list = job_group_info[job_group_selected].keys()
		# job_run_list = ['VPN', 'ROUTING']
			
		# job_run_list = None
		test_suite_list = None
		test_case_list = None
		
		
		context = {
		'job_groups': job_group_info_view,
		'job_group_selected': job_group_selected,
		'job_run_list': job_run_list,
		'test_suite_list': test_suite_list,
		'test_case_list': test_case_list
		}

		return render(request, self.template_name, context)

	def post(self, request, *args, **kwargs):
		return render(request, self.template_name, context)		


class JobTestsuite(View):
	# template_name = 'product_index_old.html'
	template_name = 'job_scheduler.html'
	robot_data = GetRobotService().get_robot_service()
	
	def get(self, request, job_group_selected=None, job_testsuite_selected=None, *args, **kwargs):
		suite_info, job_group_info = self.robot_data.get_suiteinfo()
		print(job_group_info)

		#get all job groups
		job_group_info_view = job_group_info.keys()
		#add the full and custom to the above
		job_group_info_view.extend(['full','custom'])
		
		#get the list of suite names in the group
		job_run_list = job_group_info[job_group_selected].keys()
		# job_run_list = ['VPN', 'ROUTING']
		
		#get the testsuite list
		test_suite_list = ['testsuite1','testsuite2']

		# job_run_list = None
		# test_suite_list = None
		test_case_list = None
		
		context = {
		'job_groups': job_group_info_view,
		'job_group_selected': job_group_selected,
		'job_run_list': job_run_list,
		'job_testsuite_selected': job_testsuite_selected,
		'test_suite_list': test_suite_list,
		'test_case_list': test_case_list
		}

		return render(request, self.template_name, context)

	def post(self, request, *args, **kwargs):
		return render(request, self.template_name, context)		



class JobTestcase(View):
	# template_name = 'product_index_old.html'
	template_name = 'job_scheduler.html'
	robot_data = GetRobotService().get_robot_service()
	
	def get(self, request, job_group_selected=None, job_testsuite=None, *args, **kwargs):
		suite_info, job_group_info = self.robot_data.get_suiteinfo()
		print(job_group_info)

		#get all job groups
		job_group_info_view = job_group_info.keys()
		#add the full and custom to the above
		job_group_info_view.extend(['full','custom'])
		
		#get the list of suite names in the group
		job_run_list = job_group_info[job_group_selected].keys()
		# job_run_list = ['VPN', 'ROUTING']
		
		#get the testsuite list
		test_suite_list = ['testsuite1','testsuite2']

		# job_run_list = None
		# test_suite_list = None
		test_case_list = None
		
		print('hihiiih')
		print(job_group_selected)
		print(job_run_list)
		context = {
		'job_groups': job_group_info_view,
		'job_group_selected': job_group_selected,
		'job_run_list': job_run_list,
		'job_testsuite': job_testsuite,
		'test_suite_list': test_suite_list,
		'test_case_list': test_case_list
		}

		return render(request, self.template_name, context)

	def post(self, request, *args, **kwargs):
		return render(request, self.template_name, context)		



class JobView(View):
	# template_name = 'product_index_old.html'
	template_name = 'job_view.html'

	
	def get(self, request, id=None, *args, **kwargs):
		context = {}
		return render(request, self.template_name, context)

	def post(self, request, *args, **kwargs):
		return render(request, self.template_name, context)		





class JobCompleted(View):
	# template_name = 'product_index_old.html'
	template_name = 'job_completed.html'

	
	def get(self, request, id=None, *args, **kwargs):
		context = {}
		return render(request, self.template_name, context)

	def post(self, request, *args, **kwargs):
		return render(request, self.template_name, context)		

